describe('A karma test', function() {
  it('should run in both browsers', function() {
    expect(Object.observe).toBeDefined();
  });
});
